const express = require('express');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = Number(process.env.PORT || 3000);
const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const defaults = { goldBadla:0, silverBadla:0, making18:0, making20:0, making22:0, making24:0, silverMaking:0, gstPercent:3, silverRtgsAdd:0 };
function readSettings(){
  try { return {...defaults, ...JSON.parse(fs.readFileSync(SETTINGS_FILE,'utf8'))}; }
  catch { return {...defaults}; }
}
function writeSettings(s){ fs.writeFileSync(SETTINGS_FILE, JSON.stringify(s,null,2)); }
function auth(req,res,next){
  const expected = process.env.ADMIN_PASSWORD;
  if(!expected) return res.status(503).json({error:'ADMIN_PASSWORD server .env में सेट नहीं है'});
  if(req.get('x-admin-password') !== expected) return res.status(401).json({error:'Unauthorized'});
  next();
}
async function fetchJson(url, key){
  if(!url) throw new Error('Provider URL not configured');
  const headers = {Accept:'application/json'};
  if(key) headers.Authorization = `Bearer ${key}`;
  const r = await fetch(url,{headers,signal:AbortSignal.timeout(8000),cache:'no-store'});
  if(!r.ok) throw new Error(`Provider HTTP ${r.status}`);
  return r.json();
}
// Provider adapter contract: see README. Never generate or randomize a market price here.
app.get('/api/market-data', async (req,res)=>{
  const errors = {};
  let mcx=null, spot=null, fx=null;
  try { mcx=await fetchJson(process.env.MCX_DATA_URL,process.env.MCX_API_KEY); }
  catch(e){ errors.mcx=e.message; }
  try { spot=await fetchJson(process.env.METALS_SPOT_URL,process.env.METALS_API_KEY); }
  catch(e){ errors.spot=e.message; }
  try { fx=await fetchJson(process.env.FX_DATA_URL,process.env.FX_API_KEY); }
  catch(e){ errors.fx=e.message; }
  // Normalize only the documented adapter response schema. Missing values remain null.
  const out = {
    timestamp: new Date().toISOString(),
    mcx: mcx ? {
      gold: {last:Number(mcx.gold?.last),bid:Number(mcx.gold?.bid),ask:Number(mcx.gold?.ask)},
      silver: {last:Number(mcx.silver?.last),bid:Number(mcx.silver?.bid),ask:Number(mcx.silver?.ask)}
    } : null,
    spot: spot ? {goldUsdOz:Number(spot.goldUsdOz),silverUsdOz:Number(spot.silverUsdOz)} : null,
    fx: fx ? {usdInr:Number(fx.usdInr)} : null,
    errors
  };
  const valid = out.mcx && Number.isFinite(out.mcx.gold.last) && Number.isFinite(out.mcx.silver.last);
  if(!valid) return res.status(503).json({error:'अधिकृत MCX real-time feed से वैध डेटा नहीं मिला',errors:out.errors});
  res.set('Cache-Control','no-store');
  res.json(out);
});
app.get('/api/settings',(req,res)=>res.json(readSettings()));
app.put('/api/settings',auth,(req,res)=>{
  const allowed=Object.keys(defaults);
  const next=readSettings();
  for(const k of allowed){
    if(req.body[k] !== undefined){
      const n=Number(req.body[k]);
      if(!Number.isFinite(n) || n < 0 || n > 10000000) return res.status(400).json({error:`Invalid value: ${k}`});
      next[k]=n;
    }
  }
  writeSettings(next);res.json(next);
});
app.get('/api/health',(req,res)=>res.json({ok:true,configured:{mcx:!!process.env.MCX_DATA_URL,spot:!!process.env.METALS_SPOT_URL,fx:!!process.env.FX_DATA_URL}}));
app.listen(PORT,()=>console.log(`AMIT JEWELLERS Live Rates running on http://localhost:${PORT}`));
